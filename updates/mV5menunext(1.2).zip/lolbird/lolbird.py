import sys
import subprocess

# Automatische installatie van pygame als het niet gevonden wordt
try:
    import pygame
except ImportError:
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pygame"])
        import pygame
    except Exception as e:
        print(f"Fout bij installeren van pygame: {e}")
        sys.exit(1)

import random
import os

pygame.init()
pygame.mixer.init()

# Basis directory van dit script
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Icoon pad relatief aan scriptmap
ico_path = os.path.join(BASE_DIR, "lolbird.ico")

# Icoon laden en instellen


try:
    icon = pygame.image.load(ico_path)
    pygame.display.set_icon(icon)
except pygame.error:
    print("Icoon niet gevonden, standaard icoon wordt gebruikt.")

# Venster maken na het instellen van het icoon, met RESIZABLE
WIDTH, HEIGHT = 600, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("LolBird")
clock = pygame.time.Clock()
FPS = 60

# Kleuren
YELLOW = (255, 255, 0)
SKY_BLUE = (135, 206, 235)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 200, 0)
RED = (200, 0, 0)
DARK_GRAY = (50, 50, 50)

# Fonts
FONT = pygame.font.SysFont("Arial", 36)
SMALL_FONT = pygame.font.SysFont("Arial", 24)

# Logo pad en laden
logo_path = os.path.join(BASE_DIR, "lolbird.png")
try:
    logo_img = pygame.image.load(logo_path).convert_alpha()
except pygame.error:
    logo_img = None


# Button class met extra parameters voor kleur en tekstkleur
class Button:
    def __init__(self, rect, text, color=GREEN, hover_color=RED):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.hovered = False

    def draw(self, surface, font=FONT, text_color=WHITE):
        color = self.hover_color if self.hovered else self.color
        pygame.draw.rect(surface, color, self.rect)
        text_surf = font.render(self.text, True, text_color)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)

    def is_hover(self, pos):
        return self.rect.collidepoint(pos)

# Menu buttons
menu_buttons = [
    Button((WIDTH//2 - 100, 300, 200, 50), "Start spel"),
    Button((WIDTH//2 - 100, 370, 200, 50), "Over"),
    Button((WIDTH//2 - 100, 440, 200, 50), "Afsluiten (m)"),
]

# Tab buttons voor Over scherm
tab_buttons = [
    Button((150, 120, 150, 40), "Makers"),
    Button((350, 120, 200, 40), "Software versie"),
]

# Vogel eigenschappen
bird_x = 100
bird_y = HEIGHT // 2
bird_radius = 20
bird_speed = 0
gravity = 0.5

# Pijpen eigenschappen
pipe_width = 80
pipe_gap = 150
pipe_speed = 3
pipe_color = (0, 155, 0)  # iets donkerder groen
pipes = []

score = 0

pipe_gap = 200  # Groter gat tussen bovenste en onderste pijp (verhoog dit)

def reset_game():
    global bird_y, bird_speed, pipes, score
    bird_y = HEIGHT // 2
    bird_speed = 0
    pipes = []
    score = 0
    # Pijpen dichter bij elkaar, afstand verlaagd naar 300
    for i in range(2):
        add_pipe(WIDTH + i * (pipe_width + 300))  # kortere afstand

def move_pipes():
    global score
    rem = []
    add_new_pipe = False
    for pipe in pipes:
        pipe["x"] -= pipe_speed
        if pipe["x"] + pipe_width < 0:
            rem.append(pipe)
            add_new_pipe = True
        if pipe["x"] + pipe_width < bird_x and not pipe.get("scored", False):
            score += 1
            pipe["scored"] = True
    for r in rem:
        pipes.remove(r)
    if add_new_pipe:
        add_pipe(WIDTH + 300)  # kortere afstand tussen nieuwe pijp

def add_pipe(x):
    height_top = random.randint(50, HEIGHT - pipe_gap - 100)
    pipes.append({"x": x, "top": height_top})

def draw_pipes():
    for pipe in pipes:
        pygame.draw.rect(screen, pipe_color, (pipe["x"], 0, pipe_width, pipe["top"]))
        bottom_y = pipe["top"] + pipe_gap
        pygame.draw.rect(screen, pipe_color, (pipe["x"], bottom_y, pipe_width, HEIGHT - bottom_y))


def check_collision():
    # Val naar de grond of bovenkant
    if bird_y - bird_radius < 0 or bird_y + bird_radius > HEIGHT:
        return True
    # Botsen met pijpen
    for pipe in pipes:
        px = pipe["x"]
        # Bovenste pijp
        if bird_x + bird_radius > px and bird_x - bird_radius < px + pipe_width:
            if bird_y - bird_radius < pipe["top"] or bird_y + bird_radius > pipe["top"] + pipe_gap:
                return True
    return False

def draw_score():
    score_surf = FONT.render(f"Score: {score}", True, BLACK)
    screen.blit(score_surf, (10, 10))

def game_over_screen():
    global WIDTH, HEIGHT, screen  # voeg hier toe

    restart_button = Button((WIDTH//2 - 110, HEIGHT//2 + 10, 200, 50), "Opnieuw", color=GREEN, hover_color=RED)
    back_button = Button((WIDTH//2 - 110, HEIGHT//2 + 70, 200, 50), "Terug (m)", color=GREEN, hover_color=RED)

    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_m:
                    running = False  # Terug naar menu bij 'm' toets
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if restart_button.is_hover(mouse_pos):
                    running = False
                    run_game()  # Spel opnieuw starten
                    return
                elif back_button.is_hover(mouse_pos):
                    running = False  # Terug naar menu
            if event.type == pygame.VIDEORESIZE:
                WIDTH, HEIGHT = event.w, event.h
                screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)

        screen.fill(SKY_BLUE)

        over_text = FONT.render("Game Over", True, RED)
        over_rect = over_text.get_rect(center=(WIDTH//2, HEIGHT//2 - 50))
        screen.blit(over_text, over_rect)

        restart_button.hovered = restart_button.is_hover(mouse_pos)
        back_button.hovered = back_button.is_hover(mouse_pos)
        restart_button.draw(screen)
        back_button.draw(screen)

        instruct_text = SMALL_FONT.render("Druk op 'M' om terug te gaan", True, BLACK)
        instruct_rect = instruct_text.get_rect(center=(WIDTH//2, HEIGHT//2 + 140))
        screen.blit(instruct_text, instruct_rect)

        pygame.display.flip()
        clock.tick(FPS)

def run_game():
    global bird_y, bird_speed, WIDTH, HEIGHT, screen  # hier ook global

    reset_game()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_m:
                    running = False
                if event.key == pygame.K_SPACE:
                    bird_speed = -10
            if event.type == pygame.VIDEORESIZE:
                WIDTH, HEIGHT = event.w, event.h
                screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)

        bird_speed += gravity
        bird_y += bird_speed

        move_pipes()

        screen.fill(SKY_BLUE)

        # Pijpen tekenen
        draw_pipes()

        # Vogel tekenen
        pygame.draw.circle(screen, YELLOW, (bird_x, int(bird_y)), bird_radius)
        # zwart oogje, iets rechtsboven in de vogel
        pygame.draw.circle(screen, (0, 0, 0), (bird_x + bird_radius // 2, int(bird_y) - bird_radius // 2), bird_radius // 4)

        # Logo rechtsboven
        if logo_img:
            logo_scaled = pygame.transform.scale(logo_img, (70, 70))
            screen.blit(logo_scaled, (WIDTH - 70, 10))

        draw_score()

        pygame.display.flip()
        clock.tick(FPS)

        if check_collision():
            game_over_screen()
            running = False

def show_about():
    global WIDTH, HEIGHT, screen  # hier ook global

    selected_tab = 0
    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_m:
                    return
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for i, tab in enumerate(tab_buttons):
                    if tab.is_hover(mouse_pos):
                        selected_tab = i
            if event.type == pygame.VIDEORESIZE:
                WIDTH, HEIGHT = event.w, event.h
                screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)

        screen.fill(SKY_BLUE)

        # Tabs tekenen
        for i, tab in enumerate(tab_buttons):
            tab.hovered = tab.is_hover(mouse_pos) or (i == selected_tab)
            color = BLACK if (i == selected_tab) else DARK_GRAY
            tab.draw(screen, font=SMALL_FONT, text_color=color)

        # Content per tab
        if selected_tab == 0:
            makers_lines = [
                "Makers:",
                "mV5menu:",
                "- Bedenker: Marinus",
                "- Doel: Gebruiksvriendelijke menu's en spellen",
                "- Voor: Onderwijs, hobby, prototypes",
                "- Periode: 2023-2025",
                "",
                "ChatGPT (OpenAI):",
                "- AI-assistent voor ideeën en code",
                "- Ondersteunt creatieve samenwerking",
            ]
            for i, line in enumerate(makers_lines):
                text_surf = SMALL_FONT.render(line, True, BLACK)
                screen.blit(text_surf, (150, 180 + i * 25))
        else:
            version_lines = [
                "Software versie 1.0:",
                "- LolBird Flappy Bird concept",
                "- Spel met vogel, buizen en score",
                "- Menu met start, over en afsluiten",
                "- Afsluiten met 'm' toets",
                "- Twee tabbladen in Over scherm",
                "- Game over met keuze opnieuw of terug",
                "- Professionele footer toegevoegd"
            ]
            for i, line in enumerate(version_lines):
                text_surf = SMALL_FONT.render(line, True, BLACK)
                screen.blit(text_surf, (150, 180 + i * 25))

        # Footer
        footer_text = SMALL_FONT.render("mV5menu 2023-2025", True, DARK_GRAY)
        footer_rect = footer_text.get_rect(center=(WIDTH//2, HEIGHT - 30))
        screen.blit(footer_text, footer_rect)

        # Terug instructie
        back_text = SMALL_FONT.render("Druk op 'M' om terug te keren", True, BLACK)
        back_rect = back_text.get_rect(center=(WIDTH//2, HEIGHT - 60))
        screen.blit(back_text, back_rect)

        pygame.display.flip()
        clock.tick(FPS)

def show_menu():
    global WIDTH, HEIGHT, screen  # hier ook global

    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_m:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for b in menu_buttons:
                    if b.is_hover(mouse_pos):
                        if b.text == "Afsluiten (m)":
                            pygame.quit()
                            sys.exit()
                        elif b.text == "Start spel":
                            run_game()
                        elif b.text == "Over":
                            show_about()
            if event.type == pygame.VIDEORESIZE:
                WIDTH, HEIGHT = event.w, event.h
                screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)

        screen.fill(SKY_BLUE)

        # Logo bovenaan menu
        if logo_img:
            logo_scaled = pygame.transform.scale(logo_img, (300, 300))
            logo_rect = logo_scaled.get_rect(midtop=(WIDTH // 2, 40))
            screen.blit(logo_scaled, logo_rect)


        for b in menu_buttons:
            b.hovered = b.is_hover(mouse_pos)
            b.draw(screen)

        pygame.display.flip()
        clock.tick(FPS)

if __name__ == "__main__":
    show_menu()
