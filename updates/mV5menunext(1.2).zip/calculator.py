import tkinter as tk
from tkinter import ttk

class Calculator(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Rekenmachine")
        self.geometry("260x360")
        self.configure(bg="#1e1e1e")
        self.resizable(True, True)

        self.bind("<m>", lambda event: self.quit())  # Druk op 'm' om af te sluiten
        self.create_widgets()

    def create_widgets(self):
        self.entry = ttk.Entry(self, font=("Helvetica", 18), justify="right")
        self.entry.pack(fill="x", ipadx=5, ipady=15, padx=10, pady=15)

        self.create_buttons()

        self.exit_button = tk.Button(
            self,
            text="Afsluiten (of druk op 'm')",
            font=("Helvetica", 10),
            command=self.quit,
            bg="#444444", fg="white", activebackground="#666666"
        )
        self.exit_button.pack(pady=5)

    def create_buttons(self):
        btn_frame = tk.Frame(self, bg="#1e1e1e")
        btn_frame.pack()

        buttons = [
            ['7', '8', '9', '/'],
            ['4', '5', '6', '*'],
            ['1', '2', '3', '-'],
            ['C', '0', '=', '+']
        ]

        for row_values in buttons:
            row = tk.Frame(btn_frame, bg="#1e1e1e")
            row.pack(expand=True, fill="both")
            for value in row_values:
                btn = tk.Button(
                    row, text=value, font=("Helvetica", 16), fg="white", bg="#333333",
                    activebackground="#555555", activeforeground="white",
                    height=2, width=4,
                    command=lambda val=value: self.on_click(val)
                )
                btn.pack(side="left", expand=True, fill="both", padx=2, pady=2)

    def on_click(self, value):
        if value == "C":
            self.entry.delete(0, tk.END)
        elif value == "=":
            try:
                result = eval(self.entry.get())
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, str(result))
            except:
                self.entry.delete(0, tk.END)
                self.entry.insert(tk.END, "Fout")
        else:
            self.entry.insert(tk.END, value)

if __name__ == "__main__":
    app = Calculator()
    app.mainloop()
