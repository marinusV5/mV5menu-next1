import sys
import subprocess
import os
import random

# Automatische installatie van pygame als het niet gevonden wordt
try:
    import pygame
except ImportError:
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pygame"])
        import pygame
    except Exception as e:
        print(f"Fout bij installeren van pygame: {e}")
        sys.exit(1)

pygame.init()
WIDTH, HEIGHT = 1000, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("mV5 Shooter 2D")

script_dir = os.path.dirname(os.path.abspath(__file__))
icon_path = os.path.join(script_dir, "mV5shooter2d.ico")
logo_path = os.path.join(script_dir, "mV5shooter2d.png")

pygame.display.set_icon(pygame.image.load(icon_path))
logo_img_full = pygame.image.load(logo_path)
logo_img = pygame.transform.smoothscale(logo_img_full, (120, 120))  # Klein logo

clock = pygame.time.Clock()
FONT = pygame.font.SysFont("arial", 24)
SMALL_FONT = pygame.font.SysFont("arial", 18)

state = "menu"
paused = False
show_flash = False
last_shot_time = 0
last_flash_time = 0
shoot_cooldown = 300
shoot_flash_time = 150  # ms muzzle flash duration

TILE_SIZE = 50
MAP_WIDTH, MAP_HEIGHT = 20, 15
player_pos = [100, 100]
player_size = 30
player_speed = 4
player_health = 100

weapon_length = 40
weapon_width = 10
weapon_color = (150, 150, 150)

enemy_size = 30
enemies = []

current_level = 1
max_level = 10

# Voor levels, simpele variatie: meer vijanden per level
def spawn_enemies(level):
    global enemies
    enemies = []
    enemy_count = min(3 + level, 15)
    for _ in range(enemy_count):
        while True:
            ex = random.randint(1, MAP_WIDTH - 2) * TILE_SIZE
            ey = random.randint(1, MAP_HEIGHT - 2) * TILE_SIZE
            tx = ex // TILE_SIZE
            ty = ey // TILE_SIZE
            if map_data[ty][tx] == ".":
                enemies.append(Enemy(ex, ey))
                break

class Enemy:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.health = 1
        self.speed = 1.5
        self.rect = pygame.Rect(self.x, self.y, enemy_size, enemy_size)
        self.alive = True
    
    def draw(self, surf):
        if not self.alive:
            return
        body_rect = pygame.Rect(self.x, self.y + 10, enemy_size, enemy_size - 10)
        pygame.draw.rect(surf, (200, 50, 50), body_rect)
        pygame.draw.circle(surf, (255, 224, 189), (self.x + enemy_size // 2, self.y + 10), 10)
    
    def move_towards_player(self):
        if not self.alive:
            return
        dx = player_pos[0] - self.x
        dy = player_pos[1] - self.y
        dist = max(1, (dx ** 2 + dy ** 2) ** 0.5)
        if has_line_of_sight(self.x + enemy_size/2, self.y + enemy_size/2, player_pos[0], player_pos[1]):
            self.x += self.speed * dx / dist
            self.y += self.speed * dy / dist
            self.rect.topleft = (self.x, self.y)

    def get_rect(self):
        return pygame.Rect(self.x, self.y, enemy_size, enemy_size)

def has_line_of_sight(x1, y1, x2, y2):
    steps = int(max(abs(x2 - x1), abs(y2 - y1)) // 5)
    for i in range(steps):
        lerp_x = x1 + (x2 - x1) * (i / steps)
        lerp_y = y1 + (y2 - y1) * (i / steps)
        if check_wall_collision(lerp_x, lerp_y):
            return False
    return True

class Button:
    def __init__(self, rect, text):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.hovered = False

    def draw(self, surf):
        color = (170, 170, 170) if self.hovered else (100, 100, 100)
        pygame.draw.rect(surf, color, self.rect)
        txt = FONT.render(self.text, True, (0,0,0))
        txt_rect = txt.get_rect(center=self.rect.center)
        surf.blit(txt, txt_rect)
    
    def is_hover(self, pos):
        return self.rect.collidepoint(pos)

buttons_menu = [
    Button((WIDTH//2 - 100, 200, 200, 50), "Start Game"),
    Button((WIDTH//2 - 100, 270, 200, 50), "Options"),
    Button((WIDTH//2 - 100, 340, 200, 50), "Info"),
    Button((WIDTH//2 - 100, 410, 200, 50), "Quit"),
]

buttons_options = [
    Button((WIDTH//2 - 100, 300, 200, 50), "Back"),
]

buttons_info = [
    Button((WIDTH//2 - 100, 500, 200, 50), "Back"),
]

info_tab = "updates"

map_data = [
    "####################",
    "#..................#",
    "#..####..###.......#",
    "#..................#",
    "#.......####.......#",
    "#..................#",
    "#..###........###..#",
    "#..................#",
    "#.......##.........#",
    "#..................#",
    "#..##..............#",
    "#..................#",
    "#.......####.......#",
    "#..................#",
    "####################",
]

def draw_map(surf):
    for y, row in enumerate(map_data):
        for x, tile in enumerate(row):
            rect = pygame.Rect(x*TILE_SIZE, y*TILE_SIZE, TILE_SIZE, TILE_SIZE)
            if tile == "#":
                pygame.draw.rect(surf, (70, 70, 70), rect)
            else:
                pygame.draw.rect(surf, (160, 160, 160), rect)

                

def draw_player(surf, angle):
    pygame.draw.circle(surf, (50, 100, 200), (int(player_pos[0]), int(player_pos[1])), player_size//2)

    hand_pos = (int(player_pos[0]), int(player_pos[1]))
    weapon_surf = pygame.Surface((weapon_length, weapon_width), pygame.SRCALPHA)
    weapon_surf.fill(weapon_color)
    rotated_weapon = pygame.transform.rotate(weapon_surf, -angle)
    rot_rect = rotated_weapon.get_rect(center=hand_pos)
    surf.blit(rotated_weapon, rot_rect.topleft)

    hand_offset = 15
    hand_x = hand_pos[0] + hand_offset * pygame.math.Vector2(1,0).rotate(-angle).x
    hand_y = hand_pos[1] + hand_offset * pygame.math.Vector2(1,0).rotate(-angle).y
    pygame.draw.circle(surf, (200, 150, 100), (int(hand_x), int(hand_y)), 10)

def check_wall_collision(x, y):
    tx = int(x // TILE_SIZE)
    ty = int(y // TILE_SIZE)
    if ty < 0 or ty >= MAP_HEIGHT or tx < 0 or tx >= MAP_WIDTH:
        return True
    return map_data[ty][tx] == "#"

def can_move(x, y):
    buffer = player_size // 2
    for dx, dy in [(-buffer, -buffer), (buffer, -buffer), (-buffer, buffer), (buffer, buffer)]:
        if check_wall_collision(x + dx, y + dy):
            return False
    return True

def shoot():
    global last_shot_time, last_flash_time, show_flash
    now = pygame.time.get_ticks()
    if now - last_shot_time < shoot_cooldown:
        return
    last_shot_time = now
    last_flash_time = now
    show_flash = True
    mouse_x, mouse_y = pygame.mouse.get_pos()
    dx = mouse_x - player_pos[0]
    dy = mouse_y - player_pos[1]
    dist = (dx**2 + dy**2) ** 0.5
    if dist == 0:
        return
    nx = dx / dist
    ny = dy / dist

    for enemy in enemies:
        if not enemy.alive:
            continue
        ex, ey = enemy.x + enemy_size/2, enemy.y + enemy_size/2
        vx = ex - player_pos[0]
        vy = ey - player_pos[1]
        proj = vx * nx + vy * ny
        if 0 < proj < 200:
            perp_dist = abs(vx * ny - vy * nx)
            if perp_dist < enemy_size / 2:
                enemy.health -= 1
                if enemy.health <= 0:
                    enemy.alive = False
                break

def enemies_attack_player():
    global player_health
    for enemy in enemies:
        if not enemy.alive:
            continue
        enemy_rect = enemy.get_rect()
        player_rect = pygame.Rect(player_pos[0]-player_size//2, player_pos[1]-player_size//2, player_size, player_size)
        if enemy_rect.colliderect(player_rect):
            player_health -= 0.5

def draw_health_bar(surf):
    bar_width = 200
    bar_height = 25
    x = 20
    y = 20
    pygame.draw.rect(surf, (180,0,0), (x, y, bar_width, bar_height))
    green_width = max(0, bar_width * (player_health / 100))
    pygame.draw.rect(surf, (0,200,0), (x, y, green_width, bar_height))
    txt = FONT.render(f"Health: {int(player_health)}", True, (255,255,255))
    surf.blit(txt, (x + 10, y + 2))

def draw_minimap(surf):
    map_w, map_h = 150, 100
    x = WIDTH - map_w - 20
    y = 20
    pygame.draw.rect(surf, (30,30,30), (x, y, map_w, map_h))
    tile_w = map_w / MAP_WIDTH
    tile_h = map_h / MAP_HEIGHT
    for ty, row in enumerate(map_data):
        for tx, tile in enumerate(row):
            color = (100, 100, 100) if tile == "#" else (180,180,180)
            pygame.draw.rect(surf, color, (x + tx * tile_w, y + ty * tile_h, tile_w, tile_h))
    # Player dot
    px = x + (player_pos[0] / (MAP_WIDTH * TILE_SIZE)) * map_w
    py = y + (player_pos[1] / (MAP_HEIGHT * TILE_SIZE)) * map_h
    pygame.draw.circle(surf, (0, 255, 0), (int(px), int(py)), 5)
    # Enemies dots
    for enemy in enemies:
        if enemy.alive:
            ex = x + (enemy.x / (MAP_WIDTH * TILE_SIZE)) * map_w
            ey = y + (enemy.y / (MAP_HEIGHT * TILE_SIZE)) * map_h
            pygame.draw.circle(surf, (255, 0, 0), (int(ex), int(ey)), 4)

def draw_level_info(surf):
    txt = FONT.render(f"Level {current_level}", True, (255, 255, 255))
    surf.blit(txt, (20, 60))

def draw_pause_text(surf):
    txt = FONT.render("PAUSED - Press ESC to resume, Q to quit to menu", True, (255, 255, 255))
    rect = txt.get_rect(center=(WIDTH//2, HEIGHT//2))
    surf.blit(txt, rect)

def draw_menu():
    screen.fill((255, 255, 255))  # Witte achtergrond voor menu
    # Klein logo bovenaan midden
    logo_rect = logo_img.get_rect(center=(WIDTH//2, 80))
    screen.blit(logo_img, logo_rect)
    # Buttons onder het logo met wat ruimte
    mouse_pos = pygame.mouse.get_pos()
    for i, b in enumerate(buttons_menu):
        b.rect.topleft = (WIDTH//2 - 100, 150 + i * 70)
        b.hovered = b.is_hover(mouse_pos)
        b.draw(screen)


def draw_options():
    screen.fill((60, 60, 60))
    # Klein logo boven opties
    logo_rect = logo_img.get_rect(center=(WIDTH//2, 100))
    screen.blit(logo_img, logo_rect)
    title = FONT.render("Opties - Nog niet veel hier", True, (255,255,255))
    screen.blit(title, (WIDTH//2 - title.get_width()//2, 150))
    mouse_pos = pygame.mouse.get_pos()
    for b in buttons_options:
        b.rect.topleft = (WIDTH//2 - 100, 300)
        b.hovered = b.is_hover(mouse_pos)
        b.draw(screen)

def draw_info():
    screen.fill((80, 80, 80))
    # Klein logo boven info
    logo_rect = logo_img.get_rect(center=(WIDTH//2, 80))
    screen.blit(logo_img, logo_rect)

    title = FONT.render("Info", True, (255,255,255))
    screen.blit(title, (WIDTH//2 - title.get_width()//2, 120))
    
    # Tabs
    tab_updates = pygame.Rect(WIDTH//2 - 200, 160, 150, 40)
    tab_controls = pygame.Rect(WIDTH//2 - 30, 160, 150, 40)
    tab_about = pygame.Rect(WIDTH//2 + 140, 160, 150, 40)
    mouse_pos = pygame.mouse.get_pos()

    color_active = (100, 150, 220)
    color_inactive = (100, 100, 100)

    pygame.draw.rect(screen, color_active if info_tab=="updates" else color_inactive, tab_updates)
    pygame.draw.rect(screen, color_active if info_tab=="controls" else color_inactive, tab_controls)
    pygame.draw.rect(screen, color_active if info_tab=="about" else color_inactive, tab_about)

    screen.blit(FONT.render("Updates", True, (0,0,0)), (tab_updates.x+20, tab_updates.y+5))
    screen.blit(FONT.render("Controls", True, (0,0,0)), (tab_controls.x+20, tab_controls.y+5))
    screen.blit(FONT.render("About", True, (0,0,0)), (tab_about.x+20, tab_about.y+5))

    if info_tab == "updates":
        lines = [
           
            "V1.1 - Eerste werkende versie van het spel."
        ]
        for i, line in enumerate(lines):
            txt = SMALL_FONT.render(line, True, (255,255,255))
            screen.blit(txt, (WIDTH//2 - 180, 210 + i*30))

    elif info_tab == "controls":
        lines = [
            "Beweging: WASD of pijltjestoetsen",
            "Schieten: Linkermuisknop",
            "Pauze: ESC",
            "Terug naar menu: Q (in pauze)",
            "Esc in menu sluit het spel"
        ]
        for i, line in enumerate(lines):
            txt = SMALL_FONT.render(line, True, (255,255,255))
            screen.blit(txt, (WIDTH//2 - 180, 210 + i*30))

    elif info_tab == "about":
        lines = [
            "mV5shooter 2D",
            "Gemaakt door ChatGPT en mV5menu!",
            "Dit spel toont basale AI en pygame",
            "graphics met veel functies en menu's.",
            "mV5menu 2023-2025"
        ]
        for i, line in enumerate(lines):
            txt = SMALL_FONT.render(line, True, (255,255,255))
            screen.blit(txt, (WIDTH//2 - 180, 210 + i*30))

    for b in buttons_info:
        b.rect.topleft = (WIDTH//2 - 100, 500)
        b.hovered = b.is_hover(mouse_pos)
        b.draw(screen)

def main():
    global state, paused, player_pos, player_health, current_level, info_tab, show_flash

    spawn_enemies(current_level)
    
    running = True
    while running:
        dt = clock.tick(60)
        mouse_pos = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            if state == "menu":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for b in buttons_menu:
                        if b.is_hover(mouse_pos):
                            if b.text == "Start Game":
                                state = "playing"
                                player_health = 100
                                player_pos[:] = [100, 100]
                                current_level = 1
                                spawn_enemies(current_level)
                            elif b.text == "Options":
                                state = "options"
                            elif b.text == "Info":
                                state = "info"
                            elif b.text == "Quit":
                                running = False

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False

            elif state == "options":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for b in buttons_options:
                        if b.is_hover(mouse_pos) and b.text == "Back":
                            state = "menu"

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        state = "menu"

            elif state == "info":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for b in buttons_info:
                        if b.is_hover(mouse_pos) and b.text == "Back":
                            state = "menu"
                    # Check tabs
                    tab_updates = pygame.Rect(WIDTH//2 - 200, 160, 150, 40)
                    tab_controls = pygame.Rect(WIDTH//2 - 30, 160, 150, 40)
                    tab_about = pygame.Rect(WIDTH//2 + 140, 160, 150, 40)
                    if tab_updates.collidepoint(mouse_pos):
                        info_tab = "updates"
                    elif tab_controls.collidepoint(mouse_pos):
                        info_tab = "controls"
                    elif tab_about.collidepoint(mouse_pos):
                        info_tab = "about"

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        state = "menu"

            elif state == "playing":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        paused = not paused
                    if event.key == pygame.K_q and paused:
                        state = "menu"
                        paused = False
                
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if not paused:
                        shoot()

        if state == "playing" and not paused:
            keys = pygame.key.get_pressed()
            new_x, new_y = player_pos[0], player_pos[1]
            if keys[pygame.K_w] or keys[pygame.K_UP]:
                new_y -= player_speed
            if keys[pygame.K_s] or keys[pygame.K_DOWN]:
                new_y += player_speed
            if keys[pygame.K_a] or keys[pygame.K_LEFT]:
                new_x -= player_speed
            if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
                new_x += player_speed

            if can_move(new_x, player_pos[1]):
                player_pos[0] = new_x
            if can_move(player_pos[0], new_y):
                player_pos[1] = new_y

            for enemy in enemies:
                enemy.move_towards_player()
            enemies_attack_player()

            if player_health <= 0:
                # terug naar menu bij dood
                state = "menu"
                player_health = 100
            
            # Check level klaar (alle enemies dood)
            if all(not e.alive for e in enemies):
                current_level += 1
                if current_level > max_level:
                    state = "menu"
                else:
                    spawn_enemies(current_level)
                    player_pos[:] = [100, 100]
                    player_health = 100

        screen.fill((50, 50, 50))
        
        if state == "menu":
            draw_menu()
        elif state == "options":
            draw_options()
        elif state == "info":
            draw_info()
        elif state == "playing":
            draw_map(screen)
            mx, my = pygame.mouse.get_pos()
            dx = mx - player_pos[0]
            dy = my - player_pos[1]
            angle = (180 / 3.14159) * -pygame.math.Vector2(dx, dy).angle_to((1, 0))
            draw_player(screen, angle)

            for enemy in enemies:
                enemy.draw(screen)

            draw_health_bar(screen)
            draw_minimap(screen)
            draw_level_info(screen)

            if paused:
                draw_pause_text(screen)

            if show_flash:
                now = pygame.time.get_ticks()
                if now - last_flash_time > shoot_flash_time:
                    show_flash = False
                else:
                    # Muzzle flash boven speler (aan wapenuiteinde)
                    flash_pos = (player_pos[0] + weapon_length * pygame.math.Vector2(1,0).rotate(-angle).x,
                                 player_pos[1] + weapon_length * pygame.math.Vector2(1,0).rotate(-angle).y)
                    pygame.draw.circle(screen, (255, 255, 0), (int(flash_pos[0]), int(flash_pos[1])), 12)

            # Klein logo bovenaan game
            logo_rect = logo_img.get_rect(center=(WIDTH//2, 30))
            screen.blit(logo_img, logo_rect)

        pygame.display.flip()
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
