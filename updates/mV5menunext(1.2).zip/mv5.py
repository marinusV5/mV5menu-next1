import tkinter as tk
from PIL import Image, ImageTk
import os
import subprocess
import glob

base_path = os.path.dirname(os.path.abspath(__file__))
mv5_path = os.path.join(base_path, "mv5menu")

def open_batch_ignore_version(base_name):
    pattern_folder = os.path.join(mv5_path, f"{base_name}(*")
    matching_folders = glob.glob(pattern_folder)
    print(f"Gevonden folders voor '{base_name}': {matching_folders}")

    if not matching_folders:
        print(f"Geen map gevonden voor {base_name}")
        return

    folder = matching_folders[0]

    pattern_bat = os.path.join(folder, f"{base_name}*.bat")
    matching_batches = glob.glob(pattern_bat)
    print(f"Gevonden batchbestanden in '{folder}': {matching_batches}")

    if not matching_batches:
        print(f"Geen batchbestand gevonden in {folder}")
        return

    batch_path = os.path.abspath(matching_batches[0])
    print(f"Te openen batchbestand: {batch_path}")

    if os.path.exists(batch_path):
        try:
            # Start batch via cmd /c start "" "batch_path" zodat het in nieuw venster opent
            subprocess.Popen(
                ['cmd.exe', '/c', 'start', '', batch_path],
                shell=True
            )
            root.after(500, lambda: root.focus_force())
        except Exception as e:
            print(f"Fout bij openen batch: {e}")
    else:
        print(f"Bestand niet gevonden: {batch_path}")

def load_logo(name):
    try:
        path = os.path.join(mv5_path, name)
        img = Image.open(path)
        img = img.resize((150, 150), Image.LANCZOS)
        return ImageTk.PhotoImage(img)
    except Exception as e:
        print(f"Kon logo niet laden: {name}, {e}")
        return None

root = tk.Tk()
root.title("mV5 Menu Launcher")
root.geometry("600x400")
root.configure(bg="green")

logo_24 = load_logo("24.png")
logo_green21 = load_logo("green21.jpg")

btn_24 = tk.Button(
    root,
    image=logo_24,
    text="mV5menu24",
    compound="top",
    command=lambda: open_batch_ignore_version("mV5menu24")
)
btn_24.pack(pady=10)

btn_green21 = tk.Button(
    root,
    image=logo_green21,
    text="mV5menugreen",
    compound="top",
    command=lambda: open_batch_ignore_version("mV5menugreen")
)
btn_green21.pack(pady=10)

def close_app(event=None):
    root.destroy()

btn_exit = tk.Button(root, text="Afsluiten (m)", command=close_app)
btn_exit.pack(pady=20)

root.bind("m", close_app)

root.mainloop()
